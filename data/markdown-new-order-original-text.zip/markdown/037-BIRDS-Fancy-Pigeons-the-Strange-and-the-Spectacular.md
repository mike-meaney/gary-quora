## Fancy Pigeons - the Strange and the Spectacular
    
**Upvotes**: 3,731 | **Comments**: 38 | **Date**: [2y](https://www.quora.com/What-is-the-craziest-domesticated-animal-to-ever-exist/answer/Gary-Meaney)

In my opinion, that honour goes to the domestic pigeon. In the 10,000 years since their domestication, the birds have been selectively bred into countless bizarre forms, collectively known as “fancy pigeons”.

Ever wondered if there was a pigeon with the erectile fan-shaped tail of a turkey? Probably not, but check.

![](https://qph.fs.quoracdn.net/main-qimg-4f8b1417756a32c745044479ce3567bb-lq)

What about a pigeon with a huge puffy crop? Check.

![](https://qph.fs.quoracdn.net/main-qimg-8389788f70e822905303647388b67f18-lq)

Pigeons with curly feathers on their wings? Check.

![](https://qph.fs.quoracdn.net/main-qimg-4d73fa837f7ad799a40cd3aecfa4abdf.webp)

Pigeons with huge feathers on their feet and powdery down? Check.

![](https://qph.fs.quoracdn.net/main-qimg-3d6045f285dd9f8790765c1cf1a513f3-lq)

Pigeons with fleshy, flower-like wattles all over their faces? Check.

![](https://qph.fs.quoracdn.net/main-qimg-70ba3984971705756362e421760f6995-lq)

Pigeons with that, plus scrawny giraffe necks? Check.

![](https://qph.fs.quoracdn.net/main-qimg-25f77a5dd3904061640b330b772683aa-lq)

Flightless pigeons that look and act like chickens? Check.

![](https://qph.fs.quoracdn.net/main-qimg-e03bd9b23b35f75e78f8dbe2961be55e-lq)

Pigeons with enormous ruffs like parka hoods? Check.

![](https://qph.fs.quoracdn.net/main-qimg-17dc151ecf27768e83f055bef750959e-lq)

Pigeons with virtually non-existent beaks? Check.

![](https://qph.fs.quoracdn.net/main-qimg-434f4a90211156d10315df1bec58477f-lq)

Bug-eyed pigeons? You guessed it, check.

![](https://qph.fs.quoracdn.net/main-qimg-fecf006b5b50e03fd3ccdc4ad27e2ce3-lq)

In a way, it saddens me that we’ve practically engineered these natural creatures to suit our strange desires. At least they’re not unhealthy, though - unlike so many poor dogs, especially purebreds.

