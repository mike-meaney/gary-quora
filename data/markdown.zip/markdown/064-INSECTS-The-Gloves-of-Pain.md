
## 64. The Gloves of Pain

One of the most grim and brutal initiation rites in the world is that of the Sateré-Mawé people of Brazil. To become a man and a warrior, a boy must endure hundreds of stings from bullet ants.

Bullet ants are the only species in the world with a score of “4-plus” on the Schmidt Sting Pain Index, which goes from 1 to 4. A single sting is described as causing “pure, intense, brilliant pain . . . like walking over flaming charcoal with a three-inch nail embedded in your heel."

In preparation for the rites of passage, countless bullet ants are rendered unconscious by a natural sedative. They are then woven into a pair of oven mitt-like gloves, 80 in each, with the stinging abdomens facing inwards. After the sedative wears off, the terrible ritual is ready to begin.

The boy must slip on the gloves and keep them on for a full five minutes, while singing and dancing, and maintaining his composure. For the next few days, he may shake uncontrollably, and parts of his forearm and hand will probably be paralyzed from the venom.

The worst part? Over the next months, the boy will have to endure these five minutes of agony 20 times! Only then will he be considered a man.

So, kids - if you think your life is hard, at least you don’t have to experience the most painful sting known to mankind hundreds, if not thousands, of times, over. The Sateré-Mawé are the definition of hardcore.

