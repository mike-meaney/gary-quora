
## 87. Don't Judge a Bug By its Cover

Solifuges

Also known as camel spiders, solifuges are arachnids, not quite spiders though, which can grow to over six inches in diameter. In addition to this, they have enormous chelicerae and are covered in long hair. Also, they can run at an impressive 16 km/h. In other words, they’re pretty damn scary.

There are many, many myths about solifuges. Roman manuscripts erroneously cited them as responsible for the evacuation of an entire African nation. Urban legends seriously exaggerate their size, speed, ferociousness and dangerousness. One family in Essex evacuated their home when they found a solifuge in it, and claimed it killed their dog.

However, none of that is true. Solifuges are more or less harmless; there are a few recorded cases of people getting mild nips, but they are entirely non-venomous. The myths surrounding their venomousness arose when a paper stated that solifuge “venom” was fatal to a test mouse.

However, since there is no way the solifuge could administer the venom and the substance was injected into the mouse, it’s established that this is just a non-venom substances which is lethal in the bloodstream (many animals’ blood and saliva are).

