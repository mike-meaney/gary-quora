
# INTRODUCTION

This book all began back in 2019. I was 14 years of age and I setup an account on Quora .... <backstory of book plus thanks and inspiration>
