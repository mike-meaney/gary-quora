
## 21. A Sweaty Horse is a Soapy Horse

Horses perspire in the same manner as we, and all mammals, do - via the eccrine and apocrine sweat glands clustered underneath the epidermis. These glands produce sweat - a salty, water-rich secretion, which regulates temperature through evaporative cooling.

What’s special about horse sweat is that it contains a protein called latherin, a naturally-occuring detergent - and this applies to zebras, not just domestic horses, by the way.

As you probably know, members of the horse family generally excel at long-distance running - they’re one of the only animals which are better than humans at it. The key thing about long-distance running which makes it difficult is overheating - as such, horses are also the only animals which sweat as much as we do.

However, what horses have and we don’t is a coat of (albeit short) hair. That makes it hard for the sweat glands to rapidly transport sweat from the skin to the ends of the hairs where it can evaporate. The horses’ solution to this is latherin.

The protein - being a detergent - lathers up the horse hair, living up to its name, wetting them so that water can flow efficiently from the base to the ends, where evaporative cooling occurs.

So, there’s everything about sweaty horses you never wanted to know.

