
## 14. A Conga Line of Shrews

Baby shrews travel in conga lines.

When a mother shrew wants to take her babies places, one will carry her tail in its mouth, then its sibling will do the same to it, and so on. These “caravans” can comprise up to 7 or 8 shrews.

To be fair, though, they look a bit less cute when viewed from further away. In fact, they can look like huge, dark, furry centipedes:

As a less heart-melting aside, a similar behaviour is known from - of all things - a bizarre marine arthropod from the Cambrian period. Synophalos was a shrimp-like creature which evidently travelled in chains, sometimes twenty individuals long.

Another cool fact about shrews is that their brains shrink by 15% in the winter, so they can survive the food-scarce winter. Anyway, I’m getting distracted - this has been my No. 1 cute animal fact you might not know, thanks for reading.

