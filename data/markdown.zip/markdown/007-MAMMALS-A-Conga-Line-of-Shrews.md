## A Conga Line of Shrews
    
**Upvotes**: 3,066 | **Comments**: 20 | **Date**: [2y](https://www.quora.com/What-are-some-animal-facts-that-will-melt-your-heart/answer/Gary-Meaney)

Baby shrews travel in conga lines.

![](https://qph.fs.quoracdn.net/main-qimg-15aa3869f68bd6e711613809657b33fb-lq)

When a mother shrew wants to take her babies places, one will carry her tail in its mouth, then its sibling will do the same to it, and so on. These “caravans” can comprise up to 7 or 8 shrews.

![](https://qph.fs.quoracdn.net/main-qimg-66cde3fddd208c2c833f95a90ca90422-lq)

To be fair, though, they look a bit less cute when viewed from further away. In fact, they can look like huge, dark, furry centipedes:

![](https://qph.fs.quoracdn.net/main-qimg-9fe5976e7ae32fac08e9ec5c0a3ea99f)

As a less heart-melting aside, a similar behaviour is known from - of all things - a bizarre marine arthropod from the Cambrian period. Synophalos was a shrimp-like creature which evidently travelled in chains, sometimes twenty individuals long.

![](https://qph.fs.quoracdn.net/main-qimg-d01240b60d50f23c29fbbf2ae5611ed9-pjlq)

Another cool fact about shrews is that their brains shrink by 15% in the winter, so they can survive the food-scarce winter. Anyway, I’m getting distracted - this has been my No. 1 cute animal fact you might not know, thanks for reading.

