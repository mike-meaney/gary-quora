
## 88. The Living Matryoshka Doll

There are a lot of great answers to this question already, but I know a creature which should make a great addition to the list. I’m talking about Gyrodactylus \- the living matryoshka doll.

Gyrodactylus is a genus of flatworm. There are many species within this genus, but all live in the oceans and are parasites of fish. On the outside, they don’t look like much, but Gyrodactylus worms are one of the weirdest animals I know of.

They’re viviparous - that is, they give birth to live young like we do, rather than laying eggs - which is fairly interesting as it is. However, Gyrodactylus exhibit an extremely rare form of viviparity known as hyperviviparity. Here’s how it works.

Via asexual reproduction, the flatworm produces a female embryo. But instead of leaving the “womb”, the daughter stays there and generates a second embryo - all in utero. The result is a Gyrodactylus inside a Gyrodactylus inside a Gyrodactylus.

In fact, I recall reading in one paper that sometimes there can be up to 5 nested generations in a Gyrodactylus flatworm! These creatures really are like living Russian dolls. Imagine being pregnant and carrying your great great granddaughter in your belly.

