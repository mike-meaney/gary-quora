
## 37. Fancy Pigeons - the Strange and the Spectacular

In my opinion, that honour goes to the domestic pigeon. In the 10,000 years since their domestication, the birds have been selectively bred into countless bizarre forms, collectively known as “fancy pigeons”.

Ever wondered if there was a pigeon with the erectile fan-shaped tail of a turkey? Probably not, but check.

What about a pigeon with a huge puffy crop? Check.

Pigeons with curly feathers on their wings? Check.

Pigeons with huge feathers on their feet and powdery down? Check.

Pigeons with fleshy, flower-like wattles all over their faces? Check.

Pigeons with that, plus scrawny giraffe necks? Check.

Flightless pigeons that look and act like chickens? Check.

Pigeons with enormous ruffs like parka hoods? Check.

Pigeons with virtually non-existent beaks? Check.

Bug-eyed pigeons? You guessed it, check.

In a way, it saddens me that we’ve practically engineered these natural creatures to suit our strange desires. At least they’re not unhealthy, though - unlike so many poor dogs, especially purebreds.

