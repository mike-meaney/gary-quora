
## 30. The Most Powerful Muscle on Earth

Surprisingly, this honour does not go to any kind of chameleon as you’d naturally think, but of all things, a type of salamander.

Bolitaglossa is a genus of salamander - specifically, lungless salamander. I’ll give you three guesses to guess why they’re called that. They’re gill-less, too, so they just breathe through their skin.

According to the paper [Extremely high-power tongue projection in plethodontid salamanders](https://jeb.biologists.org/content/210/4/655.full "jeb.biologists.org"), salamanders of the genus Bolitaglossa are capable of protracting their tongue from full extension in a ridiculous 3 milliseconds!

When these amazing critters shoot out their tongues, they produce 18,000 watts of power per kilogram of muscle, beating chameleons by several thousand watts. The tongue of a Bolitoglossa salamander is the fastest and most powerful muscle known to man.

