
## 80. The World's Fastest Animal - Not What You Think

As animals go, the cheetah is pretty slow - that is, if we’re talking about things relative to body size. While mathematically, bigger animals will be faster, I think that this measurement is the one which gives animals the admiration they merit.

So, what is the fastest animal relative to its size? As said, it’s not the cheetah, and it’s not the peregrine falcon or golden eagle either. It is in fact the humble South California mite.

This obscure creature, also known as Paratarsotomus macropalpis, is able to run 332 of its body length in a single second, as opposed to a cheetah’s meager 16. If you were able to be this fast for your size, you could run at speeds of 2,092 kilometres per hour! The figures are staggering.

Unfortunately, this mite is only a fraction of a centimetre long, so the sight of it racing along isn’t all that spectacular.

Anyway, not only is this mite able to move with incredible speed, it can do so in extreme conditions. South California mites were observed running at top velocity - which of course produces a lot of heat - on 60° C concrete! Furthermore, they’re agile too, and can stop or turn in an instant.

It’s really quite surprising that this animal is so little known.

