
## 90. Heavy Metal in the Animal Kingdom

Yes, absolutely. Your skeleton is made of calcium phosphate, one of the components of which is of course calcium - a metal. Your blood is full of hemoglobin, made largely of iron. Magnesium and zinc help your muscles contract and the manufacture of your DNA.

If you mean the more stereotypical image of metal as a shiny, uh, metallic plating, then the answer is still yes. This is the scaly-foot gastropod, who has a shell plated in iron sulfide. It has a visible metallic shine.

The foul, repulsive bloodworm, a type of polychaete worm, has hooked teeth which are made out of copper.

For these animals to exist, they must have had prehistoric ancestors. Unless these metallic organs are extremely recent innovations, there would have been extinct animals which shared their traits.

